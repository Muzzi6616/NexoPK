import Navigation from '@/components/Navigation';
import Hero from '@/components/Hero';
import PromoSection from '@/components/PromoSection';
import CategoryShowcase from '@/components/CategoryShowcase';
import FeaturedDeals from '@/components/FeaturedDeals';
import Testimonials from '@/components/Testimonials';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-black">
      <Navigation />
      <main className="flex-1">
        <Hero />
        <PromoSection />
        <CategoryShowcase />
        <FeaturedDeals />
        <Testimonials />
      </main>
      <Footer />
    </div>
  );
}
