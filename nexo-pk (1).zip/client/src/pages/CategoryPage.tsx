import { useState, useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import { useCart } from '@/contexts/CartContext';
import { MessageCircle, Search } from 'lucide-react';
import { toast } from 'sonner';

const categoryNames: Record<string, string> = {
  women_bags: "Women's Luxury Bags",
  men_watches: "Men's Premium Watches",
  trending: "Trending Finds",
  daily_essentials: "Daily Essentials",
};

export default function CategoryPage() {
  const { category } = useParams<{ category: string }>();
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const { addToCart } = useCart();

  const { data: products = [], isLoading } = trpc.products.getByCategory.useQuery(
    { category: category || '' },
    { enabled: !!category }
  );

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleProductClick = (product: typeof products[0]) => {
    const productSlug = product.name.toLowerCase().replace(/\s+/g, '-');
    navigate(`/product/${productSlug}`);
  };

  const handleAddToCart = (product: typeof products[0]) => {
    addToCart({
      id: product.id.toString(),
      productName: product.name,
      productPrice: product.price,
      quantity: 1,
    });
    toast.success(`${product.name} added to cart!`);
  };

  const handleWhatsApp = (productName: string) => {
    const message = `I want to order the ${productName}`;
    window.open(
      `https://wa.me/923317787831?text=${encodeURIComponent(message)}`,
      '_blank'
    );
  };

  if (!category) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <p className="text-white text-xl">Category not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <div className="bg-black border-b border-cyan-500/20 sticky top-0 z-40">
        <div className="container py-6">
          <h1 className="font-display text-4xl font-bold text-cyan-400 mb-4">
            {categoryNames[category] || category}
          </h1>
          
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-4 top-3 text-cyan-400" size={20} />
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-black border border-cyan-500/50 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-cyan-400 focus:neon-glow transition-all"
            />
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="container py-12">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <p className="text-white/70">Loading products...</p>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="flex items-center justify-center py-12">
            <p className="text-white/70">No products found</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="group glassmorphic rounded-xl p-6 border border-cyan-500/30 hover:border-cyan-400 hover:neon-glow transition-all duration-300 cursor-pointer"
                onClick={() => handleProductClick(product)}
              >
                {/* Product Image */}
                {product.image && (
                  <div className="mb-4 overflow-hidden rounded-lg h-48 bg-black/50 cursor-pointer" onClick={(e) => {
                    e.stopPropagation();
                    handleProductClick(product);
                  }}>
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                )}

                {/* Product Info */}
                <h3 className="font-display text-xl font-bold text-white mb-2">
                  {product.name}
                </h3>
                
                {product.description && (
                  <p className="font-body text-white/70 text-sm mb-4 line-clamp-2">
                    {product.description}
                  </p>
                )}

                {/* Price */}
                <div className="mb-4">
                  <p className="font-display text-2xl font-bold text-cyan-400">
                    Rs. {product.price.toLocaleString()}
                  </p>
                </div>

                {/* Buttons */}
                <div className="flex gap-3">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAddToCart(product);
                    }}
                    className="flex-1 bg-cyan-500 hover:bg-cyan-400 text-black font-bold py-2 px-4 rounded-lg transition-all duration-300 neon-glow"
                  >
                    ADD TO CART
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleWhatsApp(product.name);
                    }}
                    className="flex-1 bg-green-500 hover:bg-green-400 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-all duration-300"
                  >
                    <MessageCircle size={18} />
                    WHATSAPP
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
