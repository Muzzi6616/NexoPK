import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { Check } from 'lucide-react';

export default function OrderSuccess() {
  const [, setLocation] = useLocation();
  const [orderNumber, setOrderNumber] = useState<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setOrderNumber(params.get('orderNumber'));
  }, []);

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center">
        {/* Animated Checkmark */}
        <div className="mb-8 flex justify-center">
          <div className="relative w-24 h-24">
            {/* Outer circle with glow */}
            <div className="absolute inset-0 rounded-full border-2 border-cyan-400 animate-pulse" />
            
            {/* Inner circle */}
            <div className="absolute inset-2 rounded-full bg-gradient-to-br from-cyan-400/20 to-cyan-500/10 flex items-center justify-center">
              <Check className="w-12 h-12 text-cyan-400 animate-bounce" strokeWidth={3} />
            </div>
          </div>
        </div>

        {/* Thank You Message */}
        <h1 className="text-4xl font-bold text-white mb-2 font-display">
          Thank You!
        </h1>
        <p className="text-xl text-cyan-400 mb-6 font-display">
          Order Confirmed
        </p>

        {/* Order Details */}
        <div className="bg-gradient-to-br from-cyan-500/10 to-cyan-600/5 border border-cyan-500/30 rounded-lg p-6 mb-8 backdrop-blur-sm">
          <p className="text-white/70 text-sm mb-2">Your Order Number</p>
          <p className="text-2xl font-bold text-cyan-400 font-mono break-all">
            {orderNumber || 'Loading...'}
          </p>
        </div>

        {/* Message */}
        <div className="space-y-4 mb-8">
          <p className="text-white/80">
            Your order has been successfully placed! We'll confirm it shortly via WhatsApp.
          </p>
          <p className="text-white/60 text-sm">
            Save your order number for tracking purposes.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            onClick={() => setLocation('/')}
            className="w-full py-3 px-6 bg-gradient-to-r from-cyan-400 to-cyan-500 text-black font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-400/50 transition-all duration-300 font-display uppercase"
          >
            Continue Shopping
          </button>
          <button
            onClick={() => {
              const text = `Hi Nexo PK, my order number is ${orderNumber}. Please confirm my order.`;
              window.open(`https://wa.me/923317787831?text=${encodeURIComponent(text)}`, '_blank');
            }}
            className="w-full py-3 px-6 bg-green-500 text-white font-bold rounded-lg hover:bg-green-600 transition-all duration-300 font-display uppercase"
          >
            Message on WhatsApp
          </button>
        </div>
      </div>
    </div>
  );
}
