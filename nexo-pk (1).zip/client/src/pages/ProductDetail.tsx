import { useState } from 'react';
import { useParams, useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import { useCart } from '@/contexts/CartContext';
import { MessageCircle, ChevronLeft, ChevronRight, ShoppingCart } from 'lucide-react';
import { toast } from 'sonner';

export default function ProductDetail() {
  const params = useParams<{ productId?: string }>();
  const productId = params?.productId;
  const [, navigate] = useLocation();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();

  // Mock product data - in real app, fetch from API using productId
  const mockProducts: Record<string, any> = {
    'premium-leather-crossbody': {
      id: 1,
      name: 'Premium Leather Crossbody',
      price: 4999,
      category: 'women_bags',
      description: 'Elegant Italian leather crossbody bag with adjustable strap',
      fullDescription: 'Experience luxury with our Premium Leather Crossbody bag, crafted from the finest Italian leather. Features an adjustable strap for comfortable wear, interior pockets for organization, and a timeless design that complements any outfit. Perfect for daily use or special occasions.',
      images: [
        'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&h=800&fit=crop',
        'https://images.unsplash.com/photo-1564466809058-bf4114d55352?w=800&h=800&fit=crop',
        'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&h=800&fit=crop',
      ],
      specs: {
        Material: 'Italian Leather',
        Dimensions: '28cm x 20cm x 10cm',
        Weight: '650g',
        Warranty: '2 Years',
      },
    },
    'chronograph-luxury-watch': {
      id: 2,
      name: 'Chronograph Luxury Watch',
      price: 12999,
      category: 'men_watches',
      description: 'Swiss-inspired chronograph with leather strap',
      fullDescription: 'Elevate your wrist game with our Chronograph Luxury Watch. Featuring a Swiss-inspired movement, precision chronograph functionality, and a premium leather strap. Water-resistant up to 50m, this timepiece is perfect for both formal and casual occasions.',
      images: [
        'https://images.unsplash.com/photo-1523170335258-f5ed11844a49?w=800&h=800&fit=crop',
        'https://images.unsplash.com/photo-1524592094714-0f3e3639c62e?w=800&h=800&fit=crop',
        'https://images.unsplash.com/photo-1523170335258-f5ed11844a49?w=800&h=800&fit=crop',
      ],
      specs: {
        Movement: 'Swiss-Inspired Quartz',
        Case: 'Stainless Steel',
        'Water Resistance': '50m',
        Warranty: '3 Years',
      },
    },
  };

  const product = mockProducts[productId || ''];

  if (!product) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-xl mb-4">Product not found</p>
          <button
            onClick={() => navigate('/')}
            className="bg-cyan-500 hover:bg-cyan-400 text-black font-bold py-2 px-6 rounded-lg"
          >
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart({
        id: product.id.toString(),
        productName: product.name,
        productPrice: product.price,
        quantity: 1,
      });
    }
    toast.success(`${quantity} × ${product.name} added to cart!`);
    setQuantity(1);
  };

  const handleWhatsApp = () => {
    const message = `I'm interested in the ${product.name} (Rs. ${product.price.toLocaleString()})`;
    const url = `https://wa.me/923317787831?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % product.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length);
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <div className="bg-black border-b border-cyan-500/20 sticky top-0 z-40">
        <div className="container py-4 flex items-center gap-4">
          <button
            onClick={() => navigate('/')}
            className="text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            <ChevronLeft size={24} />
          </button>
          <h1 className="font-display text-2xl font-bold text-cyan-400">
            Product Details
          </h1>
        </div>
      </div>

      {/* Product Content */}
      <div className="container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Image Gallery */}
          <div className="flex flex-col gap-4">
            {/* Main Image */}
            <div className="relative h-96 md:h-[500px] bg-black/50 rounded-lg overflow-hidden border border-cyan-500/30">
              <img
                src={product.images[currentImageIndex]}
                alt={product.name}
                className="w-full h-full object-cover"
              />

              {/* Image Navigation */}
              {product.images.length > 1 && (
                <>
                  <button
                    onClick={prevImage}
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/70 hover:bg-black text-cyan-400 p-2 rounded-full transition-all"
                  >
                    <ChevronLeft size={24} />
                  </button>
                  <button
                    onClick={nextImage}
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/70 hover:bg-black text-cyan-400 p-2 rounded-full transition-all"
                  >
                    <ChevronRight size={24} />
                  </button>

                  {/* Image Counter */}
                  <div className="absolute bottom-4 right-4 bg-black/70 text-cyan-400 px-3 py-1 rounded-full text-sm">
                    {currentImageIndex + 1} / {product.images.length}
                  </div>
                </>
              )}
            </div>

            {/* Thumbnail Gallery */}
            {product.images.length > 1 && (
              <div className="flex gap-3">
                {product.images.map((image: string, index: number) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-20 h-20 rounded-lg overflow-hidden border-2 transition-all ${
                      index === currentImageIndex
                        ? 'border-cyan-400 neon-glow'
                        : 'border-cyan-500/30 hover:border-cyan-400'
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="flex flex-col gap-6">
            {/* Title & Price */}
            <div>
              <h1 className="font-display text-4xl font-bold text-white mb-2">
                {product.name}
              </h1>
              <p className="text-white/70 text-lg mb-4">{product.description}</p>
              <div className="text-4xl font-bold text-cyan-400 mb-2">
                Rs. {product.price.toLocaleString()}
              </div>
              <p className="text-green-400 text-sm">✓ Free Delivery Over Rs. 5000</p>
            </div>

            {/* Full Description */}
            <div className="glassmorphic p-6 rounded-lg border border-cyan-500/30">
              <h3 className="font-display text-lg font-bold text-cyan-400 mb-3">
                About This Product
              </h3>
              <p className="text-white/80 leading-relaxed">
                {product.fullDescription}
              </p>
            </div>

            {/* Specifications */}
            <div className="glassmorphic p-6 rounded-lg border border-cyan-500/30">
              <h3 className="font-display text-lg font-bold text-cyan-400 mb-4">
                Specifications
              </h3>
              <div className="space-y-3">
                {Object.entries(product.specs).map(([key, value]: [string, any]) => (
                  <div key={key} className="flex justify-between text-white/80">
                    <span className="font-semibold">{key}:</span>
                    <span>{value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quantity & Actions */}
            <div className="space-y-4">
              {/* Quantity Selector */}
              <div className="flex items-center gap-4 glassmorphic p-4 rounded-lg border border-cyan-500/30">
                <span className="text-white font-semibold">Quantity:</span>
                <div className="flex items-center gap-3 bg-black/50 rounded-lg p-2">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="text-cyan-400 hover:text-cyan-300 font-bold w-8 h-8 flex items-center justify-center"
                  >
                    −
                  </button>
                  <span className="text-white font-bold w-8 text-center">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="text-cyan-400 hover:text-cyan-300 font-bold w-8 h-8 flex items-center justify-center"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={handleAddToCart}
                  className="flex-1 bg-cyan-500 hover:bg-cyan-400 text-black font-bold py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition-all neon-glow"
                >
                  <ShoppingCart size={20} />
                  ADD TO CART
                </button>
                <button
                  onClick={handleWhatsApp}
                  className="flex-1 bg-green-500 hover:bg-green-400 text-white font-bold py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition-all"
                >
                  <MessageCircle size={20} />
                  WHATSAPP
                </button>
              </div>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-cyan-500/20">
              <div className="text-center">
                <div className="text-2xl mb-2">🚚</div>
                <p className="text-white/70 text-sm">Free Delivery</p>
              </div>
              <div className="text-center">
                <div className="text-2xl mb-2">💳</div>
                <p className="text-white/70 text-sm">Cash on Delivery</p>
              </div>
              <div className="text-center">
                <div className="text-2xl mb-2">↩️</div>
                <p className="text-white/70 text-sm">7-Day Returns</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
