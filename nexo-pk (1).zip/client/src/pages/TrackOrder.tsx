import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { Search, Package, Truck, CheckCircle2 } from 'lucide-react';

const statusSteps = [
  { status: 'pending', label: 'Order Placed', icon: Package },
  { status: 'confirmed', label: 'Confirmed', icon: CheckCircle2 },
  { status: 'processing', label: 'Processing', icon: Package },
  { status: 'shipped', label: 'Shipped', icon: Truck },
  { status: 'delivered', label: 'Delivered', icon: CheckCircle2 },
];

export default function TrackOrder() {
  const [orderNumber, setOrderNumber] = useState('');
  const [searchSubmitted, setSearchSubmitted] = useState(false);
  const { data: order, isLoading, error } = trpc.orders.getByNumber.useQuery(
    { orderNumber },
    { enabled: searchSubmitted && orderNumber.length > 0 }
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (orderNumber.trim()) {
      setSearchSubmitted(true);
    }
  };

  const getStatusIndex = (status: string) => {
    return statusSteps.findIndex(step => step.status === status);
  };

  const currentStatusIndex = order ? getStatusIndex(order.status) : -1;

  return (
    <div className="min-h-screen bg-black flex flex-col">
      <Navigation />
      
      <main className="flex-1 py-20">
        <div className="container max-w-2xl">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 font-display">
              TRACK ORDER
            </h1>
            <p className="text-cyan-400 text-lg">
              Enter your order number to see the latest status
            </p>
          </div>

          {/* Search Form */}
          <form onSubmit={handleSearch} className="mb-12">
            <div className="flex gap-3">
              <div className="flex-1 relative">
                <input
                  type="text"
                  placeholder="Enter order number (e.g., NXO-1234567-ABC123)"
                  value={orderNumber}
                  onChange={(e) => setOrderNumber(e.target.value.toUpperCase())}
                  className="w-full px-4 py-3 bg-black border-2 border-cyan-400 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-cyan-300 focus:shadow-lg focus:shadow-cyan-400/50 transition-all"
                />
                <Search className="absolute right-4 top-3.5 w-5 h-5 text-cyan-400/50" />
              </div>
              <button
                type="submit"
                className="px-8 py-3 bg-gradient-to-r from-cyan-400 to-cyan-500 text-black font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-400/50 transition-all duration-300 font-display uppercase whitespace-nowrap"
              >
                Search
              </button>
            </div>
          </form>

          {/* Results */}
          {searchSubmitted && (
            <>
              {isLoading && (
                <div className="text-center py-12">
                  <div className="inline-block animate-spin">
                    <Package className="w-12 h-12 text-cyan-400" />
                  </div>
                  <p className="text-white/70 mt-4">Searching...</p>
                </div>
              )}

              {error && (
                <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-6 text-center">
                  <p className="text-red-400 font-semibold">Order not found</p>
                  <p className="text-white/60 text-sm mt-2">Please check your order number and try again</p>
                </div>
              )}

              {order && (
                <div className="space-y-8">
                  {/* Order Details Card */}
                  <div className="bg-gradient-to-br from-cyan-500/10 to-cyan-600/5 border border-cyan-500/30 rounded-lg p-6 backdrop-blur-sm">
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <p className="text-white/60 text-sm mb-1">Order Number</p>
                        <p className="text-cyan-400 font-mono font-bold break-all">{order.orderNumber}</p>
                      </div>
                      <div>
                        <p className="text-white/60 text-sm mb-1">Product</p>
                        <p className="text-white font-semibold">{order.productName}</p>
                      </div>
                      <div>
                        <p className="text-white/60 text-sm mb-1">Customer Name</p>
                        <p className="text-white">{order.customerName}</p>
                      </div>
                      <div>
                        <p className="text-white/60 text-sm mb-1">Order Date</p>
                        <p className="text-white">{new Date(order.createdAt).toLocaleDateString()}</p>
                      </div>
                    </div>
                  </div>

                  {/* Status Timeline */}
                  <div className="bg-black border border-cyan-500/20 rounded-lg p-8">
                    <h3 className="text-xl font-bold text-white mb-8 font-display">Order Status</h3>
                    
                    <div className="space-y-6">
                      {statusSteps.map((step, index) => {
                        const Icon = step.icon;
                        const isCompleted = index <= currentStatusIndex;
                        const isCurrent = index === currentStatusIndex;

                        return (
                          <div key={step.status} className="flex gap-4">
                            {/* Timeline dot and line */}
                            <div className="flex flex-col items-center">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                                isCompleted 
                                  ? 'bg-cyan-400 shadow-lg shadow-cyan-400/50' 
                                  : 'bg-white/10 border border-white/20'
                              }`}>
                                <Icon className={`w-5 h-5 ${isCompleted ? 'text-black' : 'text-white/40'}`} />
                              </div>
                              {index < statusSteps.length - 1 && (
                                <div className={`w-0.5 h-12 mt-2 ${isCompleted ? 'bg-cyan-400' : 'bg-white/10'}`} />
                              )}
                            </div>

                            {/* Status label */}
                            <div className="pt-2">
                              <p className={`font-semibold ${
                                isCompleted ? 'text-cyan-400' : 'text-white/40'
                              }`}>
                                {step.label}
                              </p>
                              {isCurrent && (
                                <p className="text-cyan-400 text-sm mt-1">Current Status</p>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Delivery Address */}
                  <div className="bg-black border border-cyan-500/20 rounded-lg p-6">
                    <h3 className="text-lg font-bold text-white mb-4 font-display">Delivery Address</h3>
                    <p className="text-white/80">{order.customerAddress}</p>
                  </div>

                  {/* Help Section */}
                  <div className="bg-gradient-to-br from-green-500/10 to-green-600/5 border border-green-500/30 rounded-lg p-6 text-center">
                    <p className="text-white/80 mb-4">Need help with your order?</p>
                    <a
                      href={`https://wa.me/923317787831?text=Hi%20Nexo%20PK%2C%20I%20have%20a%20question%20about%20order%20${order.orderNumber}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-block px-6 py-2 bg-green-500 text-white font-bold rounded-lg hover:bg-green-600 transition-all font-display uppercase"
                    >
                      Message on WhatsApp
                    </a>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
