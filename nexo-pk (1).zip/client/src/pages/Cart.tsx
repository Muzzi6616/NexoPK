import { useCart } from '@/contexts/CartContext';
import { useLocation } from 'wouter';
import { Trash2, Plus, Minus } from 'lucide-react';
import { useState } from 'react';
import CODModal from '@/components/CODModal';

export default function Cart() {
  const { cart, removeFromCart, updateQuantity, getTotal, getDeliveryCharge, isFreeDelivery, clearCart } = useCart();
  const [, setLocation] = useLocation();
  const [showCODModal, setShowCODModal] = useState(false);

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-black pt-24 pb-16">
        <div className="container">
          <h1 className="font-display text-4xl font-bold text-white mb-8">SHOPPING CART</h1>
          <div className="text-center py-16">
            <p className="font-body text-white/70 text-lg mb-8">Your cart is empty</p>
            <button
              onClick={() => setLocation('/')}
              className="px-8 py-3 bg-cyan-500 text-black font-display font-bold uppercase hover:bg-cyan-400 transition-colors"
            >
              Continue Shopping
            </button>
          </div>
        </div>
      </div>
    );
  }

  const subtotal = getTotal();
  const deliveryCharge = getDeliveryCharge();
  const total = subtotal + deliveryCharge;

  return (
    <div className="min-h-screen bg-black pt-24 pb-16">
      <div className="container">
        <h1 className="font-display text-4xl font-bold text-white mb-12">SHOPPING CART</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="space-y-4">
              {cart.map((item) => (
                <div
                  key={item.id}
                  className="glassmorphic border border-cyan-500/30 p-6 flex items-center justify-between hover:border-cyan-400/50 transition-colors"
                >
                  <div className="flex-1">
                    <h3 className="font-display text-lg font-bold text-white mb-2">{item.productName}</h3>
                    <p className="font-body text-cyan-400">Rs. {item.productPrice.toLocaleString()}</p>
                  </div>

                  {/* Quantity Controls */}
                  <div className="flex items-center gap-4 mx-6">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="p-2 hover:bg-cyan-500/20 rounded transition-colors text-cyan-400"
                    >
                      <Minus size={18} />
                    </button>
                    <span className="font-display text-white font-bold w-8 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="p-2 hover:bg-cyan-500/20 rounded transition-colors text-cyan-400"
                    >
                      <Plus size={18} />
                    </button>
                  </div>

                  {/* Item Total */}
                  <div className="text-right mr-6">
                    <p className="font-body text-white/70 text-sm mb-1">Subtotal</p>
                    <p className="font-display text-lg font-bold text-cyan-400">
                      Rs. {(item.productPrice * item.quantity).toLocaleString()}
                    </p>
                  </div>

                  {/* Remove Button */}
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="p-2 hover:bg-red-500/20 rounded transition-colors text-red-400"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="glassmorphic border border-cyan-500/30 p-8 sticky top-24">
              <h2 className="font-display text-2xl font-bold text-white mb-6">ORDER SUMMARY</h2>

              <div className="space-y-4 mb-6 border-b border-cyan-500/20 pb-6">
                <div className="flex justify-between font-body text-white/70">
                  <span>Subtotal</span>
                  <span>Rs. {subtotal.toLocaleString()}</span>
                </div>

                <div className="flex justify-between font-body">
                  <span className={isFreeDelivery() ? 'text-green-400' : 'text-white/70'}>
                    {isFreeDelivery() ? '✓ Free Delivery' : 'Delivery Charge'}
                  </span>
                  <span className={isFreeDelivery() ? 'text-green-400 font-bold' : 'text-white/70'}>
                    {isFreeDelivery() ? 'FREE' : `Rs. ${deliveryCharge}`}
                  </span>
                </div>

                {!isFreeDelivery() && (
                  <p className="font-body text-cyan-400 text-sm">
                    Add Rs. {(5000 - subtotal).toLocaleString()} more for free delivery!
                  </p>
                )}
              </div>

              <div className="flex justify-between font-display text-xl font-bold text-cyan-400 mb-8">
                <span>TOTAL</span>
                <span>Rs. {total.toLocaleString()}</span>
              </div>

              <button
                onClick={() => setShowCODModal(true)}
                className="w-full py-3 bg-cyan-500 text-black font-display font-bold uppercase hover:bg-cyan-400 transition-colors mb-4"
              >
                Proceed to Checkout
              </button>

              <button
                onClick={() => setLocation('/')}
                className="w-full py-3 border border-cyan-500/50 text-cyan-400 font-display font-bold uppercase hover:bg-cyan-500/10 transition-colors"
              >
                Continue Shopping
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* COD Modal */}
      {showCODModal && (
        <CODModal
          isOpen={showCODModal}
          onClose={() => setShowCODModal(false)}
          cartItems={cart}
          total={total}
        />
      )}
    </div>
  );
}
