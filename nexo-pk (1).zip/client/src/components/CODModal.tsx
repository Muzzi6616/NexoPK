import { useState } from 'react';
import { X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { CartItem, useCart } from '@/contexts/CartContext';

interface CODModalProps {
  isOpen: boolean;
  onClose: () => void;
  productName?: string;
  productPrice?: string;
  cartItems?: CartItem[];
  total?: number;
}

export default function CODModal({ 
  isOpen, 
  onClose, 
  productName, 
  productPrice,
  cartItems,
  total
}: CODModalProps) {
  const [, setLocation] = useLocation();
  const { clearCart } = useCart();
  const createOrderMutation = trpc.orders.create.useMutation();
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.address) {
      alert('Please fill in all fields');
      return;
    }

    setIsSubmitting(true);
    try {
      // Handle both single product and cart items
      if (cartItems && cartItems.length > 0) {
        // For cart checkout, create a combined order
        const itemsDescription = cartItems
          .map((item) => `${item.productName} (x${item.quantity})`)
          .join(', ');
        
        const order = await createOrderMutation.mutateAsync({
          productName: itemsDescription,
          productPrice: total || 0,
          customerName: formData.name,
          customerPhone: formData.phone,
          customerAddress: formData.address,
        });

        if (order) {
          clearCart();
          onClose();
          setFormData({ name: '', phone: '', address: '' });
          setLocation(`/order-success?orderNumber=${order.orderNumber}`);
        }
      } else {
        // For single product checkout
        const priceInCents = Math.round(parseFloat(productPrice?.replace(/,/g, '') || '0') * 100);
        const order = await createOrderMutation.mutateAsync({
          productName: productName || '',
          productPrice: priceInCents,
          customerName: formData.name,
          customerPhone: formData.phone,
          customerAddress: formData.address,
        });

        if (order) {
          onClose();
          setFormData({ name: '', phone: '', address: '' });
          setLocation(`/order-success?orderNumber=${order.orderNumber}`);
        }
      }
    } catch (error) {
      console.error('Failed to create order:', error);
      alert('Failed to place order. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const displayTotal = total || (productPrice ? parseFloat(productPrice.replace(/,/g, '')) : 0);
  const displayItems = cartItems && cartItems.length > 0 ? cartItems : [];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-black border border-cyan-500/30 max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl text-cyan-400 uppercase">
            Cash on Delivery
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Product Info */}
          <div className="glassmorphic p-4 rounded-lg mb-4">
            {displayItems.length > 0 ? (
              <>
                <p className="font-body text-white/70 text-sm mb-2">Items ({displayItems.length})</p>
                <div className="space-y-2 mb-4">
                  {displayItems.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span className="font-body text-white">{item.productName} x{item.quantity}</span>
                      <span className="font-body text-cyan-400">Rs. {(item.productPrice * item.quantity).toLocaleString()}</span>
                    </div>
                  ))}
                </div>
                <div className="border-t border-cyan-500/20 pt-2">
                  <p className="font-body text-white/70 text-sm">Total</p>
                  <p className="font-body text-cyan-400 font-bold text-lg">Rs. {displayTotal.toLocaleString()}</p>
                </div>
              </>
            ) : (
              <>
                <p className="font-body text-white/70 text-sm">Product</p>
                <p className="font-body text-white font-semibold">{productName}</p>
                <p className="font-body text-cyan-400 font-bold text-lg">Rs. {productPrice}</p>
              </>
            )}
          </div>

          {/* Name Field */}
          <div>
            <label className="font-body text-white/70 text-sm mb-2 block">Full Name</label>
            <Input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter your full name"
              className="bg-white/5 border-cyan-500/30 text-white placeholder:text-white/30 font-body"
              required
            />
          </div>

          {/* Phone Field */}
          <div>
            <label className="font-body text-white/70 text-sm mb-2 block">Phone Number</label>
            <Input
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="03XX-XXXXXXX"
              className="bg-white/5 border-cyan-500/30 text-white placeholder:text-white/30 font-body"
              required
            />
          </div>

          {/* Address Field */}
          <div>
            <label className="font-body text-white/70 text-sm mb-2 block">Delivery Address</label>
            <Textarea
              name="address"
              value={formData.address}
              onChange={handleChange}
              placeholder="Enter your complete delivery address"
              className="bg-white/5 border-cyan-500/30 text-white placeholder:text-white/30 font-body min-h-24 resize-none"
              required
            />
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-cyan-400 text-black font-display font-bold uppercase tracking-widest hover:bg-cyan-300 transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Processing...' : 'Confirm Order'}
          </Button>

          {/* WhatsApp Alternative */}
          <a
            href={`https://wa.me/923317787831?text=I%20want%20to%20order%20${displayItems.length > 0 ? 'from%20my%20cart' : encodeURIComponent(productName || '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="block w-full py-2 bg-green-500 text-white text-center font-body font-semibold rounded-lg hover:bg-green-600 transition-colors duration-300"
          >
            Order via WhatsApp
          </a>
        </form>
      </DialogContent>
    </Dialog>
  );
}
