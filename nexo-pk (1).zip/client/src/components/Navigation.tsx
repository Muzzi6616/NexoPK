import { useState } from 'react';
import { Menu, X, ShoppingCart } from 'lucide-react';
import { useLocation } from 'wouter';
import { useCart } from '@/contexts/CartContext';

export default function Navigation() {
  const [, setLocation] = useLocation();
  const { cart } = useCart();
  const [isOpen, setIsOpen] = useState(false);
  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);

  const navItems = [
    { label: 'Home', path: '/' },
    { label: 'Shop', path: '/' },
    { label: 'Our Story', path: '/' },
    { label: 'Track Order', path: '/track-order' },
  ];

  return (
    <nav className="fixed top-0 w-full z-50 glassmorphic border-b border-cyan-500/20">
      <div className="container flex items-center justify-between py-4">
        {/* Logo */}
        <button 
          onClick={() => setLocation('/')}
          className="font-display text-2xl font-bold text-cyan-400 hover:text-cyan-300 transition-colors"
        >
          NEXO
        </button>

        {/* Desktop Navigation */}
        <div className="hidden md:flex gap-8 items-center">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => setLocation(item.path)}
              className="text-white/80 hover:text-cyan-400 transition-colors duration-300 font-body text-sm uppercase tracking-wide"
            >
              {item.label}
            </button>
          ))}
          
          {/* Cart Icon */}
          <button
            onClick={() => setLocation('/cart')}
            className="relative p-2 text-cyan-400 hover:text-cyan-300 transition-colors"
            title="Shopping Cart"
          >
            <ShoppingCart size={24} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-cyan-400 text-black text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
        </div>

        {/* Mobile Menu Button */}
        <div className="flex items-center gap-4 md:hidden">
          {/* Mobile Cart Icon */}
          <button
            onClick={() => setLocation('/cart')}
            className="relative p-2 text-cyan-400 hover:text-cyan-300 transition-colors"
            title="Shopping Cart"
          >
            <ShoppingCart size={24} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-cyan-400 text-black text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden glassmorphic border-t border-cyan-500/20 animate-fade-in-up">
          <div className="container py-4 flex flex-col gap-4">
            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() => {
                  setLocation(item.path);
                  setIsOpen(false);
                }}
                className="text-left text-white/80 hover:text-cyan-400 transition-colors duration-300 font-body text-sm uppercase tracking-wide"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
