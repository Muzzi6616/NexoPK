export default function PromoSection() {
  const promos = [
    {
      title: 'FLASH SALE',
      subtitle: 'Up to 40% OFF',
      color: 'from-red-600 to-red-800',
    },
    {
      title: 'FREE SHIPPING',
      subtitle: 'Orders over Rs. 5000',
      color: 'from-green-600 to-green-800',
    },
    {
      title: 'EASY RETURNS',
      subtitle: '7-Day Guarantee',
      color: 'from-blue-600 to-blue-800',
    },
  ];

  return (
    <section className="py-6 bg-black border-b border-cyan-400/20">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {promos.map((promo, index) => (
            <div
              key={index}
              className={`bg-gradient-to-r ${promo.color} rounded-lg p-6 text-center text-white`}
            >
              <p className="text-sm font-bold uppercase tracking-widest">{promo.title}</p>
              <p className="text-2xl font-bold">{promo.subtitle}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
