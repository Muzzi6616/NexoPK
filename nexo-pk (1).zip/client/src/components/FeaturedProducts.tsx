import { useState } from 'react';
import { ShoppingCart, MessageCircle } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

export default function FeaturedProducts() {
  const { addToCart } = useCart();
  const [, navigate] = useLocation();

  const products = [
    {
      id: '1',
      name: 'Premium Leather Crossbody',
      price: 4999,
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/luxury-bags-iqgW9VZYKPZHbgZj7sEWTb.webp',
    },
    {
      id: '2',
      name: 'Chronograph Luxury Watch',
      price: 12999,
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/luxury-watches-QCMhbWdxxSNSvodEwBhzyd.webp',
    },
    {
      id: '3',
      name: 'Designer Sunglasses',
      price: 3499,
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/trending-accessories-NcrwG38SzboW9j9DMFBAJW.webp',
    },
    {
      id: '4',
      name: 'Premium Leather Belt',
      price: 2499,
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/trending-accessories-NcrwG38SzboW9j9DMFBAJW.webp',
    },
  ];

  const handleAddToCart = (product: any) => {
    addToCart({
      id: product.id,
      productName: product.name,
      productPrice: product.price,
      quantity: 1,
    });
    toast.success(`${product.name} added to cart!`);
  };

  const handleWhatsApp = (productName: string) => {
    const message = `I'm interested in the ${productName}`;
    window.open(
      `https://wa.me/923317787831?text=${encodeURIComponent(message)}`,
      '_blank'
    );
  };

  return (
    <section className="py-24 bg-black">
      <div className="container">
        <h2 className="font-display text-5xl font-bold text-white text-center mb-16">
          Featured Products
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="group bg-white/5 rounded-xl overflow-hidden hover:bg-white/10 transition-all duration-300 cursor-pointer"
              onClick={() => navigate(`/product/${product.name.toLowerCase().replace(/\s+/g, '-')}`)}
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden bg-black/50">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>

              {/* Info */}
              <div className="p-6">
                <h3 className="font-display text-lg font-bold text-white mb-2 line-clamp-2">
                  {product.name}
                </h3>
                <p className="text-cyan-400 font-bold text-xl mb-4">
                  Rs. {product.price.toLocaleString()}
                </p>

                {/* Buttons */}
                <div className="flex gap-3">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAddToCart(product);
                    }}
                    className="flex-1 bg-cyan-500 hover:bg-cyan-400 text-black font-bold py-2 rounded-lg transition-colors duration-300 flex items-center justify-center gap-2"
                  >
                    <ShoppingCart size={18} />
                    Add
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleWhatsApp(product.name);
                    }}
                    className="flex-1 bg-green-600 hover:bg-green-500 text-white font-bold py-2 rounded-lg transition-colors duration-300 flex items-center justify-center gap-2"
                  >
                    <MessageCircle size={18} />
                    Chat
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
