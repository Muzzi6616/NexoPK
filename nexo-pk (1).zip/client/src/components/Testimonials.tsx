import { Star } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      name: 'Ahmed Hassan',
      location: 'Karachi',
      rating: 5,
      text: 'Amazing quality! The watch I ordered exceeded my expectations. Highly recommended!',
      product: 'Chronograph Watch',
    },
    {
      name: 'Fatima Khan',
      location: 'Lahore',
      rating: 5,
      text: 'Fast delivery and excellent customer service. Will definitely order again!',
      product: 'Leather Crossbody',
    },
    {
      name: 'Usman Ali',
      location: 'Islamabad',
      rating: 4.5,
      text: 'Great products at reasonable prices. The packaging was premium quality.',
      product: 'Designer Sunglasses',
    },
    {
      name: 'Zara Malik',
      location: 'Multan',
      rating: 5,
      text: 'Best online shopping experience! Everything was perfect from start to finish.',
      product: 'Premium Belt',
    },
  ];

  return (
    <section className="py-16 bg-black border-t border-cyan-400/20">
      <div className="container">
        <h2 className="text-4xl font-bold text-white mb-12 text-center">What Customers Say</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white/5 rounded-lg p-6 hover:bg-white/10 transition-all duration-300">
              {/* Stars */}
              <div className="flex gap-1 mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={16}
                    className={i < Math.floor(testimonial.rating) ? 'fill-yellow-300 text-yellow-300' : 'text-white/20'}
                  />
                ))}
              </div>

              {/* Review Text */}
              <p className="text-white/80 mb-4 text-sm line-clamp-3">"{testimonial.text}"</p>

              {/* Product */}
              <p className="text-cyan-400 text-xs font-bold mb-3">• {testimonial.product}</p>

              {/* Author */}
              <div>
                <p className="font-bold text-white text-sm">{testimonial.name}</p>
                <p className="text-white/60 text-xs">{testimonial.location}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Trust Badges */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white/5 rounded-lg p-6 text-center hover:bg-white/10 transition-all">
            <div className="text-4xl mb-3">✓</div>
            <h3 className="font-bold text-white mb-2">100% Authentic</h3>
            <p className="text-white/60 text-sm">All products are genuine and verified</p>
          </div>
          <div className="bg-white/5 rounded-lg p-6 text-center hover:bg-white/10 transition-all">
            <div className="text-4xl mb-3">🚚</div>
            <h3 className="font-bold text-white mb-2">Fast Delivery</h3>
            <p className="text-white/60 text-sm">Quick shipping across Pakistan</p>
          </div>
          <div className="bg-white/5 rounded-lg p-6 text-center hover:bg-white/10 transition-all">
            <div className="text-4xl mb-3">💯</div>
            <h3 className="font-bold text-white mb-2">Money Back</h3>
            <p className="text-white/60 text-sm">7-day hassle-free returns</p>
          </div>
        </div>
      </div>
    </section>
  );
}
