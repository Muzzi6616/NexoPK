import { useLocation } from 'wouter';

export default function CategoryGrid() {
  const [, navigate] = useLocation();
  
  const categories = [
    {
      title: "Women's Bags",
      slug: 'women_bags',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/luxury-bags-iqgW9VZYKPZHbgZj7sEWTb.webp',
    },
    {
      title: "Men's Watches",
      slug: 'men_watches',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/luxury-watches-QCMhbWdxxSNSvodEwBhzyd.webp',
    },
    {
      title: 'Trending',
      slug: 'trending',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/trending-accessories-NcrwG38SzboW9j9DMFBAJW.webp',
    },
    {
      title: 'Essentials',
      slug: 'daily_essentials',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/daily-essentials-trending-FiDbRfDFS6LbQHEzLsphUm.webp',
    },
  ];

  return (
    <section id="shop" className="py-24 bg-black">
      <div className="container">
        <h2 className="font-display text-5xl font-bold text-white text-center mb-16">
          Shop Collections
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {categories.map((category) => (
            <div
              key={category.slug}
              onClick={() => navigate(`/category/${category.slug}`)}
              className="group relative h-72 rounded-xl overflow-hidden cursor-pointer"
            >
              {/* Background Image */}
              <img
                src={category.image}
                alt={category.title}
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />

              {/* Overlay */}
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors duration-300" />

              {/* Content */}
              <div className="absolute inset-0 flex items-center justify-center z-10">
                <h3 className="font-display text-4xl font-bold text-white text-center group-hover:text-cyan-400 transition-colors duration-300">
                  {category.title}
                </h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
