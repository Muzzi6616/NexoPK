import { useLocation } from 'wouter';

export default function Hero() {
  const [, navigate] = useLocation();

  const handleShopNow = () => {
    navigate('/category/women_bags');
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden"
      style={{
        backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/hero-cyber-luxe-MEHuTg88RmSY9KVoYdAyPL.webp)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-black/60 z-0" />

      {/* Content - Centered and Clean */}
      <div className="relative z-10 container text-center">
        <h1 className="font-display text-6xl md:text-8xl font-bold text-white mb-4 leading-tight">
          NEXO PK
        </h1>
        <p className="font-body text-xl md:text-2xl text-cyan-400 mb-8">
          Premium Lifestyle Brand
        </p>
        <p className="font-body text-lg text-white/70 mb-12 max-w-2xl mx-auto">
          Curated luxury accessories for the modern Pakistani
        </p>

        <button
          onClick={handleShopNow}
          className="px-10 py-4 bg-cyan-400 text-black font-bold text-lg rounded-lg neon-glow hover:bg-cyan-300 transition-all duration-300 hover:scale-105 active:scale-95"
        >
          EXPLORE COLLECTION
        </button>
      </div>
    </section>
  );
}
