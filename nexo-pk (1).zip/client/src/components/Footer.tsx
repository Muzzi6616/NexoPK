import { MessageCircle, Facebook } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-black border-t border-cyan-500/20">
      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div>
            <h3 className="font-display text-2xl font-bold text-cyan-400 mb-4">NEXO</h3>
            <p className="font-body text-white/70 text-sm">
              Premium lifestyle brand delivering elite accessories to modern Pakistanis.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display text-lg font-bold text-white mb-4 uppercase">Quick Links</h4>
            <ul className="space-y-2">
              {['Home', 'Shop', 'Our Story', 'Track Order'].map((link) => (
                <li key={link}>
                  <a href="#" className="font-body text-white/70 hover:text-cyan-400 transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="font-display text-lg font-bold text-white mb-4 uppercase">Support</h4>
            <ul className="space-y-2">
              {[
                { label: 'Contact Us', href: '#' },
                { label: 'FAQ', href: '#' },
                { label: 'Returns', href: 'https://wa.me/923317787831?text=I%20want%20to%20know%20about%20returns%20and%20the%207-day%20return%20policy' },
                { label: 'Shipping', href: '#' },
              ].map(({ label, href }) => (
                <li key={label}>
                  <a href={href} target={href.includes('wa.me') ? '_blank' : undefined} rel={href.includes('wa.me') ? 'noopener noreferrer' : undefined} className="font-body text-white/70 hover:text-cyan-400 transition-colors text-sm">
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <h4 className="font-display text-lg font-bold text-white mb-4 uppercase">Follow Us</h4>
            <div className="flex gap-4">
              {[
                { icon: Facebook, href: 'https://www.facebook.com/share/1KonJDAusq/?mibextid=wwXIfr' },
              ].map(({ icon: Icon, href }, index) => (
                <a
                  key={index}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-lg glassmorphic flex items-center justify-center text-cyan-400 hover:neon-glow transition-all duration-300"
                >
                  <Icon size={20} />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-cyan-500/20 pt-8 text-center">
          <p className="font-body text-white/50 text-sm">
            © {currentYear} Nexo PK. All rights reserved. | Premium Lifestyle Brand
          </p>
        </div>
      </div>

      {/* Floating WhatsApp Widget */}
      <a
        href="https://wa.me/923317787831?text=Hello%20Nexo%20PK%2C%20I%20want%20to%20know%20more%20about%20your%20products"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-8 right-8 w-16 h-16 bg-green-500 rounded-full flex items-center justify-center text-white shadow-lg hover:scale-110 transition-transform duration-300 z-40 neon-glow"
        title="Chat on WhatsApp"
      >
        <MessageCircle size={32} />
      </a>
    </footer>
  );
}
