import { useLocation } from 'wouter';

export default function CategoryShowcase() {
  const [, navigate] = useLocation();

  const categories = [
    {
      title: "Women's Bags",
      slug: 'women_bags',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/luxury-bags-iqgW9VZYKPZHbgZj7sEWTb.webp',
      count: '5 Products',
    },
    {
      title: "Men's Watches",
      slug: 'men_watches',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/luxury-watches-QCMhbWdxxSNSvodEwBhzyd.webp',
      count: '5 Products',
    },
    {
      title: 'Trending',
      slug: 'trending',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/trending-accessories-NcrwG38SzboW9j9DMFBAJW.webp',
      count: '8 Products',
    },
    {
      title: 'Essentials',
      slug: 'daily_essentials',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/daily-essentials-trending-FiDbRfDFS6LbQHEzLsphUm.webp',
      count: '6 Products',
    },
  ];

  return (
    <section className="py-16 bg-black">
      <div className="container">
        <h2 className="text-4xl font-bold text-white mb-12">Shop by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {categories.map((cat) => (
            <div
              key={cat.slug}
              onClick={() => navigate(`/category/${cat.slug}`)}
              className="group cursor-pointer"
            >
              <div className="relative h-48 rounded-lg overflow-hidden mb-3 bg-black/50">
                <img
                  src={cat.image}
                  alt={cat.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors duration-300" />
              </div>
              <h3 className="font-bold text-white group-hover:text-cyan-400 transition-colors">{cat.title}</h3>
              <p className="text-sm text-white/60">{cat.count}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
