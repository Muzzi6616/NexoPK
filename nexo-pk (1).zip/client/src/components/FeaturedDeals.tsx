import { useState } from 'react';
import { ShoppingCart, MessageCircle, Star } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

export default function FeaturedDeals() {
  const { addToCart } = useCart();
  const [, navigate] = useLocation();

  const products = [
    {
      id: '1',
      name: 'Premium Leather Crossbody',
      price: 4999,
      originalPrice: 6999,
      rating: 4.8,
      reviews: 142,
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/luxury-bags-iqgW9VZYKPZHbgZj7sEWTb.webp',
      badge: 'BESTSELLER',
    },
    {
      id: '2',
      name: 'Chronograph Luxury Watch',
      price: 12999,
      originalPrice: 16999,
      rating: 4.9,
      reviews: 89,
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/luxury-watches-QCMhbWdxxSNSvodEwBhzyd.webp',
      badge: 'HOT DEAL',
    },
    {
      id: '3',
      name: 'Designer Sunglasses',
      price: 3499,
      originalPrice: 4999,
      rating: 4.7,
      reviews: 56,
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/trending-accessories-NcrwG38SzboW9j9DMFBAJW.webp',
      badge: 'TRENDING',
    },
    {
      id: '4',
      name: 'Premium Leather Belt',
      price: 2499,
      originalPrice: 3499,
      rating: 4.6,
      reviews: 73,
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663479727451/7MFVWvruNiz8d8ynPu4oGS/trending-accessories-NcrwG38SzboW9j9DMFBAJW.webp',
      badge: 'POPULAR',
    },
  ];

  const handleAddToCart = (product: any) => {
    addToCart({
      id: product.id,
      productName: product.name,
      productPrice: product.price,
      quantity: 1,
    });
    toast.success(`${product.name} added to cart!`);
  };

  const handleWhatsApp = (productName: string) => {
    const message = `I'm interested in the ${productName}`;
    window.open(
      `https://wa.me/923317787831?text=${encodeURIComponent(message)}`,
      '_blank'
    );
  };

  const handleProductClick = (productName: string) => {
    navigate(`/product/${productName.toLowerCase().replace(/\s+/g, '-')}`);
  };

  const discount = (original: number, current: number) => {
    return Math.round(((original - current) / original) * 100);
  };

  return (
    <section className="py-16 bg-black">
      <div className="container">
        <div className="flex justify-between items-center mb-12">
          <h2 className="text-4xl font-bold text-white">Featured Deals</h2>
          <button
            onClick={() => navigate('/category/women_bags')}
            className="text-cyan-400 hover:text-cyan-300 font-bold transition-colors"
          >
            View All →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="bg-white/5 rounded-lg overflow-hidden hover:bg-white/10 transition-all duration-300 group"
            >
              {/* Image Container */}
              <div className="relative h-56 bg-black/50 overflow-hidden cursor-pointer" onClick={() => handleProductClick(product.name)}>
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                {/* Badge */}
                <div className="absolute top-3 left-3 bg-red-600 text-white text-xs font-bold px-3 py-1 rounded">
                  {product.badge}
                </div>
                {/* Discount */}
                <div className="absolute top-3 right-3 bg-cyan-500 text-black text-xs font-bold px-2 py-1 rounded">
                  -{discount(product.originalPrice, product.price)}%
                </div>
              </div>

              {/* Info */}
              <div className="p-4">
                <h3
                  className="font-bold text-white mb-2 line-clamp-2 cursor-pointer hover:text-cyan-400 transition-colors"
                  onClick={() => handleProductClick(product.name)}
                >
                  {product.name}
                </h3>

                {/* Rating */}
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={i < Math.floor(product.rating) ? 'fill-yellow-300 text-yellow-300' : 'text-white/20'}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-yellow-300 font-bold">{product.rating}</span>
                  <span className="text-xs text-white/60">({product.reviews})</span>
                </div>

                {/* Price */}
                <div className="flex items-baseline gap-2 mb-4">
                  <span className="text-lg font-bold text-cyan-400">Rs. {product.price.toLocaleString()}</span>
                  <span className="text-sm text-white/50 line-through">Rs. {product.originalPrice.toLocaleString()}</span>
                </div>

                {/* Buttons */}
                <div className="flex gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAddToCart(product);
                    }}
                    className="flex-1 bg-cyan-500 hover:bg-cyan-400 text-black font-bold py-2 rounded transition-colors flex items-center justify-center gap-2"
                  >
                    <ShoppingCart size={16} />
                    Add
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleWhatsApp(product.name);
                    }}
                    className="flex-1 bg-green-600 hover:bg-green-500 text-white font-bold py-2 rounded transition-colors flex items-center justify-center gap-2"
                  >
                    <MessageCircle size={16} />
                    Chat
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
