import { Truck, CreditCard, RotateCcw } from 'lucide-react';

export default function TrustSection() {
  const benefits = [
    {
      icon: Truck,
      title: 'Free Delivery',
      description: 'Over Rs. 5000',
    },
    {
      icon: CreditCard,
      title: 'Cash on Delivery',
      description: 'Pay when you receive',
    },
    {
      icon: RotateCcw,
      title: '7-Day Returns',
      description: 'Hassle-free returns policy',
    },
  ];

  return (
    <section className="py-20 bg-black border-y border-cyan-500/20">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div
                key={benefit.title}
                className="glassmorphic p-8 rounded-lg text-center hover:neon-glow transition-all duration-300 animate-fade-in-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <Icon className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                <h3 className="font-display text-xl font-bold text-white mb-2 uppercase">
                  {benefit.title}
                </h3>
                <p className="font-body text-white/70">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
