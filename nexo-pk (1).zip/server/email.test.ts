import { describe, expect, it } from "vitest";
import { ENV } from "./_core/env";

describe("Email Configuration", () => {
  it("should have OWNER_EMAIL configured", () => {
    expect(ENV.ownerEmail).toBeDefined();
    expect(ENV.ownerEmail).toBe("salmanzamaan2@gmail.com");
    expect(ENV.ownerEmail).toMatch(/^[^\s@]+@[^\s@]+\.[^\s@]+$/); // Valid email format
  });

  it("should validate email format", () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    expect(emailRegex.test(ENV.ownerEmail)).toBe(true);
  });
});
