import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { createOrder, getOrderByNumber, updateOrderStatus, getProductsByCategory, getAllProducts } from "./db";
import { nanoid } from "nanoid";
import { z } from "zod";
import { notifyOwner } from "./_core/notification";
import { ENV } from "./_core/env";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  products: router({
    getByCategory: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ input }) => {
        return getProductsByCategory(input.category);
      }),
    getAll: publicProcedure
      .query(async () => {
        return getAllProducts();
      }),
  }),

  orders: router({
    create: publicProcedure
      .input(z.object({
        productName: z.string(),
        productPrice: z.number(),
        customerName: z.string(),
        customerPhone: z.string(),
        customerAddress: z.string(),
      }))
      .mutation(async ({ input }) => {
        const orderNumber = `NXO-${Date.now()}-${nanoid(6).toUpperCase()}`;
        const order = await createOrder({
          orderNumber,
          productName: input.productName,
          productPrice: input.productPrice,
          customerName: input.customerName,
          customerPhone: input.customerPhone,
          customerAddress: input.customerAddress,
          status: 'pending',
        });
        
        // Send email notification to owner
        if (ENV.ownerEmail) {
          try {
            await notifyOwner({
              title: `New Order Received: ${orderNumber}`,
              content: `Customer: ${input.customerName}\nPhone: ${input.customerPhone}\nAddress: ${input.customerAddress}\nProduct: ${input.productName}\nPrice: Rs. ${input.productPrice}\nOrder Number: ${orderNumber}`,
            });
          } catch (error) {
            console.error('[Email] Failed to send order notification:', error);
          }
        }
        
        return order;
      }),
    getByNumber: publicProcedure
      .input(z.object({ orderNumber: z.string() }))
      .query(async ({ input }) => {
        return getOrderByNumber(input.orderNumber);
      }),
    updateStatus: publicProcedure
      .input(z.object({
        orderNumber: z.string(),
        status: z.enum(['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled']),
      }))
      .mutation(async ({ input }) => {
        return updateOrderStatus(input.orderNumber, input.status);
      }),
  }),
});

export type AppRouter = typeof appRouter;
